"""Weight sensitivity analysis: stability intervals for a chosen criterion,
plus a chart of every alternative's net flow as that criterion's weight varies."""
import numpy as np
import plotly.graph_objects as go
import streamlit as st

from app_state import get_problem, style_download_buttons
from i18n import t
from promethee_core.core import compute_promethee
from promethee_core.sensitivity import compute_weight_sensitivity

style_download_buttons()
st.title(t("sensitivity.title"))
st.caption(t("sensitivity.caption"))

problem = get_problem()
active_crits = problem.active_criteria()
active_alts = problem.active_alternatives()

if len(active_alts) < 2 or len(active_crits) < 2:
    st.info(t("sensitivity.need_2alt_2crit"))
    st.stop()

result = compute_promethee(problem)

criterion_name = st.selectbox(t("sensitivity.criterion_to_analyze"), [c.name for c in active_crits])
top_x = st.slider(t("sensitivity.stability_slider"), 1, len(active_alts), 1)

try:
    sens = compute_weight_sensitivity(result, criterion_name)
except ValueError as exc:
    st.warning(str(exc))
    st.stop()

w_low, w_high, crossings = sens.stability_interval(top_x)

st.metric(t("sensitivity.current_weight"), f"{sens.w0:.4f}")
st.success(
    t(
        "sensitivity.stability_success",
        top_x=top_x, criterion_name=criterion_name, w_low=f"{w_low:.4f}", w_high=f"{w_high:.4f}",
    )
)

ws = np.linspace(0.0, 1.0, 201)
flows = sens.flow_at(ws)

# -- publishable style tokens (fixed light "paper" surface, independent of the
# viewer's OS/browser theme), matching the GAIA page's export styling --------
SURFACE = "#fcfcfb"
INK_PRIMARY = "#0b0b0b"
INK_SECONDARY = "#52514e"
GRIDLINE = "#e1e0d9"
FONT_FAMILY = 'system-ui, -apple-system, "Segoe UI", sans-serif'

fig = go.Figure()
for idx, name in enumerate(sens.alt_names):
    fig.add_trace(go.Scatter(x=ws, y=flows[:, idx], mode="lines", name=name))
fig.add_vline(x=sens.w0, line_dash="dash", line_color=INK_SECONDARY, annotation_text="current weight")
fig.add_vrect(x0=w_low, x1=w_high, fillcolor="LightGreen", opacity=0.15, line_width=0)
fig.update_xaxes(gridcolor=GRIDLINE, color=INK_SECONDARY, title_font=dict(color=INK_SECONDARY, family=FONT_FAMILY))
fig.update_yaxes(gridcolor=GRIDLINE, color=INK_SECONDARY, title_font=dict(color=INK_SECONDARY, family=FONT_FAMILY))
fig.update_layout(
    title=dict(
        text=f"Sensitivity of '{criterion_name}' — {problem.name}",
        font=dict(color=INK_PRIMARY, size=18, family=FONT_FAMILY),
    ),
    xaxis_title=f"Weight of '{criterion_name}'",
    yaxis_title="Net flow Phi(Ai)",
    xaxis_range=[0, 1],
    legend_title="Alternative",
    font=dict(family=FONT_FAMILY, color=INK_PRIMARY),
    paper_bgcolor=SURFACE,
    plot_bgcolor=SURFACE,
    legend=dict(bgcolor=SURFACE, font=dict(color=INK_PRIMARY, family=FONT_FAMILY)),
    margin=dict(l=60, r=40, t=60, b=60),
)
st.plotly_chart(fig, width="stretch", theme=None)

if crossings:
    st.caption(t("sensitivity.crossings_caption"))
    st.table(
        [{"Alternatives": f"{c['a']} <-> {c['b']}", "Weight at crossing": round(c["w"], 4)} for c in crossings]
    )

st.divider()
st.subheader(t("sensitivity.download_subheader"))

# Rendering the PNG spawns a local headless-browser process (via kaleido) — on
# Windows that briefly flashes a window. Doing this unconditionally on every
# rerun meant it fired on every single slider drag / selectbox change. So it's
# gated behind an explicit click instead, and the result is cached until the
# criterion or stability level actually changes.
png_context = (criterion_name, top_x)
if st.button(t("sensitivity.generate_png")):
    try:
        st.session_state["sensitivity_png_bytes"] = fig.to_image(format="png", width=1600, height=900, scale=2)
        st.session_state["sensitivity_png_context"] = png_context
    except Exception:
        st.session_state["sensitivity_png_bytes"] = None
        st.warning(t("sensitivity.no_renderer"), icon="⚠️")

cached_png = st.session_state.get("sensitivity_png_bytes")
if cached_png is not None:
    if st.session_state.get("sensitivity_png_context") != png_context:
        st.caption(t("sensitivity.stale_png"))
    else:
        st.download_button(
            t("sensitivity.download_png"),
            data=cached_png,
            file_name=f"{problem.name or 'sensitivity'}_{criterion_name}_sensitivity.png",
            mime="image/png",
        )
